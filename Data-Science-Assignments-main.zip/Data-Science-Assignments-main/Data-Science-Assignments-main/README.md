# Data-Science-Assignments

Use these links to see each assignment's code:
1. Data Exploration - https://htmlpreview.github.io/?https://github.com/noumik/Data-Science-Assignments/blob/main/1-Data%20Exploration/Assignment0.html
2. Decision Trees - https://htmlpreview.github.io/?https://github.com/noumik/Data-Science-Assignments/blob/main/2-DecisionTrees/ScikitLearnDecisionTrees.html
3. NaiveBayes & KNN - https://htmlpreview.github.io/?https://github.com/noumik/Data-Science-Assignments/blob/main/3-NaiveBayesKNN/ScikitLearnNbKnn.html
4. Clustering - https://htmlpreview.github.io/?https://github.com/noumik/Data-Science-Assignments/blob/main/4-ClusteringAnomalyDetection/HW%20-%20Clustering.html
5. Association Analysis - https://htmlpreview.github.io/?https://github.com/noumik/Data-Science-Assignments/blob/main/5-AssocationAnalysis/Assignment%205%20-%20Association%20Analysis.html
